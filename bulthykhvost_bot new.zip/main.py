
import logging
import os
from aiogram import Bot, Dispatcher, executor, types
from gtts import gTTS
from dotenv import load_dotenv
import openai

# Загружаем переменные окружения
load_dotenv()
TELEGRAM_API_TOKEN = os.getenv("TELEGRAM_API_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Настраиваем OpenAI
openai.api_key = OPENAI_API_KEY

# Настраиваем логирование
logging.basicConfig(level=logging.INFO)
bot = Bot(token=TELEGRAM_API_TOKEN)
dp = Dispatcher(bot)

# Команда /start
@dp.message_handler(commands=["start"])
async def start_handler(message: types.Message):
    await message.reply("Привет! Я Бультыхвост 🐾\nНапиши тему сказки, и я её сочиню и озвучу.")

# Генерация сказки + озвучка
@dp.message_handler()
async def fairy_tale_handler(message: types.Message):
    topic = message.text.strip()
    try:
        # Генерация текста сказки
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=f"Сочини короткую детскую сказку на тему: {topic}",
            max_tokens=400,
            temperature=0.7
        )
        tale = response.choices[0].text.strip()

        # Озвучка
        tts = gTTS(tale, lang="ru")
        file_path = f"voice_{message.from_user.id}.mp3"
        tts.save(file_path)

        # Отправляем сказку текстом + голосом
        await message.reply(tale)
        with open(file_path, "rb") as audio:
            await bot.send_voice(message.chat.id, audio)

        os.remove(file_path)
    except Exception as e:
        await message.reply("⚠️ Не удалось сочинить сказку. Попробуй снова позже.")
        logging.error(f"Ошибка: {e}")

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
    